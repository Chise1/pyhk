#include <iostream>
#include <stdio.h>
using namsespace std;
#define version "0.1"
void version(){
        std::cout>>version>>endl;
}