import hk_struct_test
x=hk_struct_test.NET_DVR_MOTION_V30()
x.reservedData=1
print(x.reservedData)