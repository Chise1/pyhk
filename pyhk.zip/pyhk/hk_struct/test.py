import hk_struct
x=hk_struct.NET_DVR_DEVICEINFO_V30()