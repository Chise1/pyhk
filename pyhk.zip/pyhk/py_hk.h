#include "HCNetSDK.h"


// void test(LPNET_DVR_TIME x);
