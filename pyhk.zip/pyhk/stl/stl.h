#include <string>
#include <vector>

using namespace std;

vector<string> vector_int2str(vector<int> input);
